# BEC v2.0 M8 Polyhedral Solver Kernel Check

Fixed version: the type-valued backend bridge constructor is a `def`, not a `theorem`.

Run from a Lean/Lake Mathlib project root:

```bash
unzip -o BECv2_M8_PolyhedralSolverCheck_FILES_FIXED.zip
chmod +x check_becv2_m8.sh
./check_becv2_m8.sh
```
