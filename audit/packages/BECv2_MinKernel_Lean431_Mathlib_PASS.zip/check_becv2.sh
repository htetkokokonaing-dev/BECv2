#!/usr/bin/env bash
set -euo pipefail

echo "[BEC v2.0] Lean/Mathlib minimum check"

if [ ! -f lakefile.lean ] && [ ! -f lakefile.toml ]; then
  echo "ERROR: Run this script from your Lean/Lake Mathlib project root."
  echo "       I could not find lakefile.lean or lakefile.toml here."
  exit 1
fi

if [ ! -f BECv2_MinCheck.lean ]; then
  echo "ERROR: BECv2_MinCheck.lean is not in this directory."
  echo "       Put BECv2_MinCheck.lean beside your lakefile first."
  exit 1
fi

echo
echo "[1/3] Lean version"
lake env lean --version

echo
echo "[2/3] Compile check"
lake env lean BECv2_MinCheck.lean

echo
echo "[3/3] Placeholder scan"
if grep -nE '(^|[^A-Za-z])(sorry|admit|axiom|unsafe)([^A-Za-z]|$)' BECv2_MinCheck.lean; then
  echo "ERROR: Placeholder or unsafe token found."
  exit 1
else
  echo "PASS: no sorry/admit/axiom/unsafe tokens found."
fi

echo
echo "PASS: BECv2_MinCheck.lean compiled successfully."
