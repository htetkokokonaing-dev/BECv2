# BEC v2.0 M12 Extended All-in-One Kernel Check

This package merges the verified milestone source files:

- M1: Universe + Graph + Licensed Route Kernel
- M2: Compiler Normal Form Soundness
- M3: Probability / Stochastic Certificate Kernel
- M4: Boolean Topology Kernel
- M5: BTT Foundation Kernel
- M8: Polyhedral Solver Kernel
- M9: Dynamic Generator Kernel

into:

`BECv2_AllInOne_Extended_Check.lean`

Run from a Lean/Lake Mathlib project root:

```bash
unzip -o BECv2_M12_AllInOneExtended_FILES.zip
chmod +x check_becv2_m12.sh
./check_becv2_m12.sh
```

Expected output:

```text
PASS: blocked-token scan clean.
PASS: BECv2_AllInOne_Extended_Check.lean compiled successfully.
```

This milestone checks that the verified core, solver, and dynamic kernels coexist in a single Lean file.
