# BEC v2.0 M14 Categorical Morphism / Lax Comparison Kernel

Fixed version: renamed `KernelMorphism.then` to `KernelMorphism.comp`, because `then` is reserved syntax in Lean.

Run from a Lean/Lake Mathlib project root:

```bash
unzip -o BECv2_M14_CategoricalCheck_FILES_FIXED.zip
chmod +x check_becv2_m14.sh
./check_becv2_m14.sh
```
