import Mathlib

/-! M1 component: BECv2_MinCheck.lean -/
/-!
# BEC v2.0 Minimum Mathlib Check Kernel

Self-contained compile target for the BEC v2.0 universe, graph layer,
licensed routes, and obstruction extraction.

Clean placeholder scan target.
-/

namespace BECv2

universe u v w a c

class ExcessValue (V : Type u) where
  le : V -> V -> Prop
  lt : V -> V -> Prop
  zero : V
  top : V
  op : V -> V -> V
  le_refl : forall x : V, le x x
  le_trans : forall {x y z : V}, le x y -> le y z -> le x z
  le_antisymm : forall {x y : V}, le x y -> le y x -> x = y
  lt_iff_le_not_le : forall {x y : V}, lt x y <-> le x y /\ Not (le y x)
  zero_le : forall x : V, le zero x
  le_top : forall x : V, le x top
  op_assoc : forall x y z : V, op (op x y) z = op x (op y z)
  zero_op : forall x : V, op zero x = x
  op_zero : forall x : V, op x zero = x
  op_comm : forall x y : V, op x y = op y x
  op_le_op_left : forall {x y : V}, le x y -> forall z : V, le (op z x) (op z y)

structure BECUniverse where
  X : Type u
  Ref : Type v
  V : Type w
  instV : ExcessValue V
  E : Ref -> X -> V
  Assump : Type a
  Claim : Type c
  Cert : Claim -> Type c

def threshold (B : BECUniverse.{u, v, w, a, c}) (A : B.Ref) (r : B.V) : Set B.X :=
  {x | B.instV.le (B.E A x) r}

def strictThreshold (B : BECUniverse.{u, v, w, a, c}) (A : B.Ref) (r : B.V) : Set B.X :=
  {x | B.instV.lt (B.E A x) r}

def shell (B : BECUniverse.{u, v, w, a, c}) (A : B.Ref) (r s : B.V) : Set B.X :=
  {x | B.instV.lt r (B.E A x) /\ B.instV.le (B.E A x) s}

def profile (B : BECUniverse.{u, v, w, a, c}) (A : B.Ref) : B.X -> B.V :=
  fun x => B.E A x

def zeroLocus (B : BECUniverse.{u, v, w, a, c}) (A : B.Ref) : Set B.X :=
  {x | B.E A x = B.instV.zero}

theorem threshold_mono
    (B : BECUniverse.{u, v, w, a, c}) (A : B.Ref) {r s : B.V}
    (hrs : B.instV.le r s) :
    threshold B A r ⊆ threshold B A s := by
  intro x hx
  exact B.instV.le_trans hx hrs

theorem shell_subset_threshold
    (B : BECUniverse.{u, v, w, a, c}) (A : B.Ref) (r s : B.V) :
    shell B A r s ⊆ threshold B A s := by
  intro x hx
  exact hx.2

theorem zeroLocus_subset_threshold
    (B : BECUniverse.{u, v, w, a, c}) (A : B.Ref) (r : B.V)
    (h0r : B.instV.le B.instV.zero r) :
    zeroLocus B A ⊆ threshold B A r := by
  intro x hx
  change B.instV.le (B.E A x) r
  rw [hx]
  exact h0r

structure Obstruction (B : BECUniverse.{u, v, w, a, c}) where
  attempted : B.Claim
  missing : Set B.Assump
  fallback : Option B.Claim

structure BoundaryThresholdGraph (B : BECUniverse.{u, v, w, a, c}) where
  N : Set B.Claim
  EG : Set (B.Claim × B.Claim)
  edge_source_mem : forall {p q : B.Claim}, (p, q) ∈ EG -> p ∈ N
  edge_target_mem : forall {p q : B.Claim}, (p, q) ∈ EG -> q ∈ N
  ell : {e : B.Claim × B.Claim // e ∈ EG} -> Nat
  gamma : {e : B.Claim × B.Claim // e ∈ EG} -> Set B.Assump
  omega : {e : B.Claim × B.Claim // e ∈ EG} -> Obstruction B

namespace BoundaryThresholdGraph

def Edge {B : BECUniverse.{u, v, w, a, c}} (G : BoundaryThresholdGraph B) :=
  {e : B.Claim × B.Claim // e ∈ G.EG}

def edgeSource {B : BECUniverse.{u, v, w, a, c}} (G : BoundaryThresholdGraph B)
    (e : Edge G) : B.Claim :=
  e.val.1

def edgeTarget {B : BECUniverse.{u, v, w, a, c}} (G : BoundaryThresholdGraph B)
    (e : Edge G) : B.Claim :=
  e.val.2

def licensedEdge {B : BECUniverse.{u, v, w, a, c}} (G : BoundaryThresholdGraph B)
    (Gamma : Set B.Assump) (e : Edge G) : Prop :=
  G.gamma e ⊆ Gamma

end BoundaryThresholdGraph

structure EdgeRealizer {B : BECUniverse.{u, v, w, a, c}}
    (G : BoundaryThresholdGraph B) where
  mapCert :
    (e : BoundaryThresholdGraph.Edge G) ->
      B.Cert (BoundaryThresholdGraph.edgeSource G e) ->
      B.Cert (BoundaryThresholdGraph.edgeTarget G e)

namespace Route

inductive RawRoute
    {B : BECUniverse.{u, v, w, a, c}}
    (G : BoundaryThresholdGraph B) :
    B.Claim -> B.Claim -> Type (max (max (max (max u v) w) a) c) where
  | refl (p : B.Claim) :
      RawRoute G p p
  | step {q : B.Claim}
      (e : BoundaryThresholdGraph.Edge G)
      (tail :
        RawRoute G
          (BoundaryThresholdGraph.edgeTarget G e)
          q) :
      RawRoute G
        (BoundaryThresholdGraph.edgeSource G e)
        q

inductive LicensedRoute
    {B : BECUniverse.{u, v, w, a, c}}
    (G : BoundaryThresholdGraph B)
    (Gamma : Set B.Assump) :
    B.Claim -> B.Claim -> Type (max (max (max (max u v) w) a) c) where
  | refl (p : B.Claim) :
      LicensedRoute G Gamma p p
  | step {q : B.Claim}
      (e : BoundaryThresholdGraph.Edge G)
      (hlic : BoundaryThresholdGraph.licensedEdge G Gamma e)
      (tail :
        LicensedRoute G Gamma
          (BoundaryThresholdGraph.edgeTarget G e)
          q) :
      LicensedRoute G Gamma
        (BoundaryThresholdGraph.edgeSource G e)
        q

def licensedRouteTransport
    {B : BECUniverse.{u, v, w, a, c}}
    {G : BoundaryThresholdGraph B}
    {Gamma : Set B.Assump}
    (R : EdgeRealizer G) :
    {p q : B.Claim} ->
      LicensedRoute G Gamma p q ->
      B.Cert p ->
      B.Cert q
  | _, _, LicensedRoute.refl _, cert => cert
  | _, _, LicensedRoute.step e _ tail, cert =>
      licensedRouteTransport R tail (R.mapCert e cert)

def licensedRouteSound
    {B : BECUniverse.{u, v, w, a, c}}
    {G : BoundaryThresholdGraph B}
    {Gamma : Set B.Assump}
    (R : EdgeRealizer G)
    {p q : B.Claim}
    (rho : LicensedRoute G Gamma p q)
    (cert : B.Cert p) :
    B.Cert q :=
  licensedRouteTransport R rho cert

def missingAssumptions
    {B : BECUniverse.{u, v, w, a, c}}
    {G : BoundaryThresholdGraph B}
    (Gamma : Set B.Assump)
    (e : BoundaryThresholdGraph.Edge G) :
    Set B.Assump :=
  G.gamma e \ Gamma

def edgeObstruction
    {B : BECUniverse.{u, v, w, a, c}}
    {G : BoundaryThresholdGraph B}
    (Gamma : Set B.Assump)
    (e : BoundaryThresholdGraph.Edge G) :
    Obstruction B :=
  {
    attempted := BoundaryThresholdGraph.edgeTarget G e
    missing := missingAssumptions Gamma e
    fallback := (G.omega e).fallback
  }

theorem edge_obstruction_missing_eq
    {B : BECUniverse.{u, v, w, a, c}}
    {G : BoundaryThresholdGraph B}
    (Gamma : Set B.Assump)
    (e : BoundaryThresholdGraph.Edge G) :
    (edgeObstruction Gamma e).missing = G.gamma e \ Gamma :=
  rfl

inductive HasUnlicensedEdge
    {B : BECUniverse.{u, v, w, a, c}}
    (G : BoundaryThresholdGraph B)
    (Gamma : Set B.Assump) :
    {p q : B.Claim} ->
      RawRoute G p q ->
      Type (max (max (max (max u v) w) a) c) where
  | head {q : B.Claim}
      (e : BoundaryThresholdGraph.Edge G)
      (tail :
        RawRoute G
          (BoundaryThresholdGraph.edgeTarget G e)
          q)
      (hbad :
        Not (BoundaryThresholdGraph.licensedEdge G Gamma e)) :
      HasUnlicensedEdge G Gamma (RawRoute.step e tail)
  | tail {q : B.Claim}
      (e : BoundaryThresholdGraph.Edge G)
      (tailRoute :
        RawRoute G
          (BoundaryThresholdGraph.edgeTarget G e)
          q)
      (h :
        HasUnlicensedEdge G Gamma tailRoute) :
      HasUnlicensedEdge G Gamma (RawRoute.step e tailRoute)

def obstructionOfUnlicensedRoute
    {B : BECUniverse.{u, v, w, a, c}}
    {G : BoundaryThresholdGraph B}
    {Gamma : Set B.Assump} :
    {p q : B.Claim} ->
      {rho : RawRoute G p q} ->
      HasUnlicensedEdge G Gamma rho ->
      Obstruction B
  | _, _, _, HasUnlicensedEdge.head e _ _ =>
      edgeObstruction Gamma e
  | _, _, _, HasUnlicensedEdge.tail _ _ h =>
      obstructionOfUnlicensedRoute h

theorem obstruction_completeness
    {B : BECUniverse.{u, v, w, a, c}}
    {G : BoundaryThresholdGraph B}
    {Gamma : Set B.Assump}
    {p q : B.Claim}
    {rho : RawRoute G p q}
    (h : HasUnlicensedEdge G Gamma rho) :
    Nonempty (Obstruction B) :=
  ⟨obstructionOfUnlicensedRoute h⟩

end Route
end BECv2


/-! M2 component: BECv2_CompilerCheck.lean -/
namespace BECv2

namespace Compiler

inductive BecSort : Type where
  | prop : BecSort
  | nat : BecSort
  | int : BecSort
  | rat : BecSort
  | real : BecSort
  | vector : BecSort -> Nat -> BecSort
  | set : BecSort -> BecSort
  | metricSpace : BecSort
  | topologicalSpace : BecSort
  | probabilitySpace : BecSort
  | custom : String -> BecSort

mutual

inductive Term : Type where
  | var : String -> BecSort -> Term
  | app : String -> List Term -> Term
  | setOf : String -> BecSort -> Formula -> Term
  | excess : Term -> Term -> Term
  | profile : Term -> Term
  | dist : Term -> Term -> Term
  | threshold : Term -> Term -> Term
  | shell : Term -> Term -> Term -> Term

inductive Formula : Type where
  | trueF : Formula
  | falseF : Formula
  | atom : String -> List Term -> Formula
  | leF : Term -> Term -> Formula
  | ltF : Term -> Term -> Formula
  | eqF : Term -> Term -> Formula
  | andF : Formula -> Formula -> Formula
  | orF : Formula -> Formula -> Formula
  | impF : Formula -> Formula -> Formula
  | notF : Formula -> Formula
  | forallF : String -> BecSort -> Formula -> Formula
  | existsF : String -> BecSort -> Formula -> Formula
  | probGe : Formula -> Term -> Formula

end

structure ProblemAST where
  context : List Formula
  goal : Formula

inductive ClaimKind : Type where
  | thresholdLE : ClaimKind
  | thresholdLT : ClaimKind
  | shell : ClaimKind
  | profileEq : ClaimKind
  | transfer : ClaimKind
  | fallback : ClaimKind
  | stochasticThreshold : ClaimKind
  | dynamicInvariant : ClaimKind

structure CompileObstruction where
  phase : String
  reason : String
  missing : List String

inductive BoundaryAtom : Type where
  | thresholdLE : Term -> Term -> Term -> Formula -> BoundaryAtom
  | thresholdLT : Term -> Term -> Term -> Formula -> BoundaryAtom
  | shell : Term -> Term -> Term -> Term -> Formula -> BoundaryAtom
  | profileEq : Term -> Term -> Formula -> BoundaryAtom

def BoundaryAtom.kind : BoundaryAtom -> ClaimKind
  | BoundaryAtom.thresholdLE _ _ _ _ => ClaimKind.thresholdLE
  | BoundaryAtom.thresholdLT _ _ _ _ => ClaimKind.thresholdLT
  | BoundaryAtom.shell _ _ _ _ _ => ClaimKind.shell
  | BoundaryAtom.profileEq _ _ _ => ClaimKind.profileEq

def parseFailure (phase : String) : CompileObstruction :=
  { phase := phase, reason := "outside BEC native fragment", missing := [] }

def parseAtom : Formula -> Except CompileObstruction BoundaryAtom
  | Formula.leF (Term.excess A x) r =>
      .ok (BoundaryAtom.thresholdLE A x r
        (Formula.leF (Term.excess A x) r))
  | Formula.ltF (Term.excess A x) r =>
      .ok (BoundaryAtom.thresholdLT A x r
        (Formula.ltF (Term.excess A x) r))
  | Formula.andF (Formula.ltF r (Term.excess A x))
                 (Formula.leF (Term.excess _ _) s) =>
      .ok (BoundaryAtom.shell A x r s
        (Formula.andF
          (Formula.ltF r (Term.excess A x))
          (Formula.leF (Term.excess A x) s)))
  | Formula.eqF (Term.profile A) (Term.profile C) =>
      .ok (BoundaryAtom.profileEq A C
        (Formula.eqF (Term.profile A) (Term.profile C)))
  | _ => .error (parseFailure "parse atom")

def normalizeFormula : Formula -> Except CompileObstruction (List BoundaryAtom)
  | Formula.andF p q => do
      let np <- normalizeFormula p
      let nq <- normalizeFormula q
      pure (np ++ nq)
  | f => do
      let a <- parseAtom f
      pure [a]

def normalizeList : List Formula -> Except CompileObstruction (List BoundaryAtom)
  | [] => .ok []
  | f :: fs => do
      let nf <- normalizeFormula f
      let nfs <- normalizeList fs
      pure (nf ++ nfs)

structure NormalForm where
  assumptions : List BoundaryAtom
  goal : List BoundaryAtom

def normalizeProblem (P : ProblemAST) : Except CompileObstruction NormalForm := do
  let ctx <- normalizeList P.context
  let g <- normalizeFormula P.goal
  pure { assumptions := ctx, goal := g }

def IsNativeAtom : BoundaryAtom -> Prop
  | BoundaryAtom.thresholdLE _ _ _ _ => True
  | BoundaryAtom.thresholdLT _ _ _ _ => True
  | BoundaryAtom.shell _ _ _ _ _ => True
  | BoundaryAtom.profileEq _ _ _ => True

def AllNativeAtoms (xs : List BoundaryAtom) : Prop :=
  forall a, a ∈ xs -> IsNativeAtom a

def NativeNormalForm (N : NormalForm) : Prop :=
  AllNativeAtoms N.assumptions /\ AllNativeAtoms N.goal

theorem native_atom_by_construction (a : BoundaryAtom) :
    IsNativeAtom a := by
  cases a <;> trivial

theorem all_native_by_construction (xs : List BoundaryAtom) :
    AllNativeAtoms xs := by
  intro a _
  exact native_atom_by_construction a

theorem parseAtom_sound
    {f : Formula} {a : BoundaryAtom}
    (_h : parseAtom f = .ok a) :
    IsNativeAtom a :=
  native_atom_by_construction a

theorem normalizeFormula_sound
    {f : Formula} {xs : List BoundaryAtom}
    (_h : normalizeFormula f = .ok xs) :
    AllNativeAtoms xs :=
  all_native_by_construction xs

theorem normalizeList_sound
    {fs : List Formula} {xs : List BoundaryAtom}
    (_h : normalizeList fs = .ok xs) :
    AllNativeAtoms xs :=
  all_native_by_construction xs

theorem normalizeProblem_sound
    {P : ProblemAST} {N : NormalForm}
    (_h : normalizeProblem P = .ok N) :
    NativeNormalForm N := by
  constructor
  · exact all_native_by_construction N.assumptions
  · exact all_native_by_construction N.goal

def sampleRef : Term :=
  Term.var "A" (BecSort.set BecSort.real)

def samplePoint : Term :=
  Term.var "x" BecSort.real

def sampleRadius : Term :=
  Term.var "r" BecSort.real

def sampleProblem : ProblemAST :=
  { context := [],
    goal := Formula.leF (Term.excess sampleRef samplePoint) sampleRadius }

def sampleNormalForm : NormalForm :=
  { assumptions := [],
    goal :=
      [BoundaryAtom.thresholdLE sampleRef samplePoint sampleRadius
        (Formula.leF (Term.excess sampleRef samplePoint) sampleRadius)] }

example :
    normalizeProblem sampleProblem = .ok sampleNormalForm := by
  rfl

example :
    NativeNormalForm sampleNormalForm :=
  normalizeProblem_sound (P := sampleProblem) (N := sampleNormalForm) rfl

end Compiler
end BECv2


/-! M3 component: BECv2_ProbabilityCheck.lean -/
namespace BECv2
namespace Prob

universe u

structure ProbKernel (Omega : Type u) where
  prob : Set Omega -> Real
  mono : forall {A B : Set Omega}, A ⊆ B -> prob A <= prob B
  inter_lower : forall A B : Set Omega, prob A + prob B - 1 <= prob (A ∩ B)

theorem union_bound_transfer
    {Omega : Type u}
    (K : ProbKernel Omega)
    (P Q R : Set Omega)
    {alpha beta : Real}
    (hPQ : P ∩ Q ⊆ R)
    (hP : alpha <= K.prob P)
    (hQ : beta <= K.prob Q) :
    alpha + beta - 1 <= K.prob R := by
  calc
    alpha + beta - 1 <= K.prob P + K.prob Q - 1 := by
      linarith
    _ <= K.prob (P ∩ Q) := K.inter_lower P Q
    _ <= K.prob R := K.mono hPQ

structure StochasticThreshold where
  alpha : Real
  radius : Real
  eventProb : Real
  licensed : alpha <= eventProb

theorem stochastic_threshold_weaken
    (C : StochasticThreshold)
    {beta : Real}
    (hbeta : beta <= C.alpha) :
    beta <= C.eventProb := by
  exact le_trans hbeta C.licensed

noncomputable def hoeffdingFailure (n : Nat) (eps : Real) : Real :=
  2 * Real.exp (-2 * (n : Real) * eps ^ 2)

noncomputable def hoeffdingConfidence (n : Nat) (eps : Real) : Real :=
  1 - hoeffdingFailure n eps

structure HoeffdingCertificate where
  n : Nat
  phat : Real
  eps : Real
  alpha : Real
  eps_nonneg : 0 <= eps
  empirical_margin : alpha <= phat - eps
  failure : Real
  failure_eq : failure = hoeffdingFailure n eps
  confidence : Real
  confidence_eq : confidence = hoeffdingConfidence n eps

theorem empirical_lower_bound
    {phat p eps alpha : Real}
    (hdev : |phat - p| <= eps)
    (hmargin : alpha <= phat - eps) :
    alpha <= p := by
  have hright : phat - p <= eps := (abs_le.mp hdev).2
  linarith

theorem empirical_certificate_sound
    (C : HoeffdingCertificate)
    {p : Real}
    (hdev : |C.phat - p| <= C.eps) :
    C.alpha <= p :=
  empirical_lower_bound hdev C.empirical_margin

theorem hoeffding_confidence_identity
    (n : Nat) (eps : Real) :
    hoeffdingConfidence n eps =
      1 - 2 * Real.exp (-2 * (n : Real) * eps ^ 2) := by
  rfl

structure EmpiricalBoundaryClaim where
  n : Nat
  radius : Real
  alpha : Real
  phat : Real
  eps : Real
  lowerBound : Real
  lower_eq : lowerBound = phat - eps
  lower_licenses : alpha <= lowerBound

theorem empirical_claim_to_margin
    (C : EmpiricalBoundaryClaim) :
    C.alpha <= C.phat - C.eps := by
  rw [← C.lower_eq]
  exact C.lower_licenses

theorem empirical_claim_sound
    (C : EmpiricalBoundaryClaim)
    {p : Real}
    (hdev : |C.phat - p| <= C.eps) :
    C.alpha <= p := by
  exact empirical_lower_bound hdev (empirical_claim_to_margin C)

structure CompositionCertificate
    {Omega : Type u}
    (K : ProbKernel Omega)
    (P Q R : Set Omega) where
  alpha : Real
  beta : Real
  transfer : P ∩ Q ⊆ R
  p_bound : alpha <= K.prob P
  q_bound : beta <= K.prob Q

theorem composition_certificate_sound
    {Omega : Type u}
    {K : ProbKernel Omega}
    {P Q R : Set Omega}
    (C : CompositionCertificate K P Q R) :
    C.alpha + C.beta - 1 <= K.prob R :=
  union_bound_transfer K P Q R C.transfer C.p_bound C.q_bound

end Prob
end BECv2


/-! M4 component: BECv2_TopologyCheck.lean -/
namespace BECv2
namespace TopologyFragment

universe u

inductive BoolV : Type where
  | zero : BoolV
  | one : BoolV
  deriving DecidableEq

namespace BoolV

def le : BoolV -> BoolV -> Prop
  | zero, _ => True
  | one, one => True
  | one, zero => False

def lt (x y : BoolV) : Prop :=
  le x y /\ Not (le y x)

def op : BoolV -> BoolV -> BoolV
  | zero, y => y
  | x, zero => x
  | one, one => one

theorem le_refl (x : BoolV) : le x x := by
  cases x <;> trivial

theorem le_trans {x y z : BoolV} :
    le x y -> le y z -> le x z := by
  intro hxy hyz
  cases x <;> cases y <;> cases z <;> trivial

theorem le_antisymm {x y : BoolV} :
    le x y -> le y x -> x = y := by
  intro hxy hyx
  cases x <;> cases y <;> try rfl
  · cases hyx
  · cases hxy

theorem zero_le (x : BoolV) : le zero x := by
  cases x <;> trivial

theorem le_one (x : BoolV) : le x one := by
  cases x <;> trivial

theorem op_assoc (x y z : BoolV) :
    op (op x y) z = op x (op y z) := by
  cases x <;> cases y <;> cases z <;> rfl

theorem zero_op (x : BoolV) : op zero x = x := by
  cases x <;> rfl

theorem op_zero (x : BoolV) : op x zero = x := by
  cases x <;> rfl

theorem op_comm (x y : BoolV) : op x y = op y x := by
  cases x <;> cases y <;> rfl

theorem op_le_op_left {x y : BoolV}
    (hxy : le x y) (z : BoolV) :
    le (op z x) (op z y) := by
  cases x <;> cases y <;> cases z <;> trivial

end BoolV

structure KuratowskiClosure (X : Type u) where
  cl : Set X -> Set X
  cl_empty : cl ∅ = ∅
  subset_cl : forall A : Set X, A ⊆ cl A
  cl_idem : forall A : Set X, cl (cl A) = cl A
  cl_union : forall A B : Set X, cl (A ∪ B) = cl A ∪ cl B

noncomputable def booleanExcess
    {X : Type u} (C : KuratowskiClosure X)
    (A : Set X) (x : X) : BoolV := by
  classical
  exact if x ∈ C.cl A then BoolV.zero else BoolV.one

def booleanThreshold
    {X : Type u} (C : KuratowskiClosure X)
    (A : Set X) (r : BoolV) : Set X :=
  {x | BoolV.le (booleanExcess C A x) r}

theorem boolean_excess_eq_zero_of_mem
    {X : Type u} (C : KuratowskiClosure X) (A : Set X) (x : X)
    (hx : x ∈ C.cl A) :
    booleanExcess C A x = BoolV.zero := by
  classical
  unfold booleanExcess
  simp [hx]

theorem boolean_excess_eq_one_of_not_mem
    {X : Type u} (C : KuratowskiClosure X) (A : Set X) (x : X)
    (hx : x ∉ C.cl A) :
    booleanExcess C A x = BoolV.one := by
  classical
  unfold booleanExcess
  simp [hx]

theorem boolean_threshold_zero_eq_closure
    {X : Type u} (C : KuratowskiClosure X) (A : Set X) :
    booleanThreshold C A BoolV.zero = C.cl A := by
  ext x
  constructor
  · intro hx
    change BoolV.le (booleanExcess C A x) BoolV.zero at hx
    by_contra hnot
    rw [boolean_excess_eq_one_of_not_mem C A x hnot] at hx
    change False at hx
    exact hx
  · intro hx
    change BoolV.le (booleanExcess C A x) BoolV.zero
    rw [boolean_excess_eq_zero_of_mem C A x hx]
    trivial

theorem boolean_threshold_one_eq_univ
    {X : Type u} (C : KuratowskiClosure X) (A : Set X) :
    booleanThreshold C A BoolV.one = Set.univ := by
  ext x
  constructor
  · intro _
    trivial
  · intro _
    change BoolV.le (booleanExcess C A x) BoolV.one
    cases h : booleanExcess C A x <;> trivial

theorem closure_subset_threshold_one
    {X : Type u} (C : KuratowskiClosure X) (A : Set X) :
    C.cl A ⊆ booleanThreshold C A BoolV.one := by
  intro x _
  rw [boolean_threshold_one_eq_univ]
  trivial

theorem threshold_zero_subset_threshold_one
    {X : Type u} (C : KuratowskiClosure X) (A : Set X) :
    booleanThreshold C A BoolV.zero ⊆ booleanThreshold C A BoolV.one := by
  intro x _
  rw [boolean_threshold_one_eq_univ]
  trivial

theorem point_in_closure_iff_zero_threshold
    {X : Type u} (C : KuratowskiClosure X) (A : Set X) (x : X) :
    x ∈ C.cl A <-> x ∈ booleanThreshold C A BoolV.zero := by
  constructor
  · intro hx
    rw [boolean_threshold_zero_eq_closure]
    exact hx
  · intro hx
    rw [boolean_threshold_zero_eq_closure] at hx
    exact hx

structure BooleanClosureBEC (X : Type u) where
  closure : KuratowskiClosure X

noncomputable def BooleanClosureBEC.excess
    {X : Type u} (M : BooleanClosureBEC X) :
    Set X -> X -> BoolV :=
  booleanExcess M.closure

def BooleanClosureBEC.threshold
    {X : Type u} (M : BooleanClosureBEC X) :
    Set X -> BoolV -> Set X :=
  fun A r => booleanThreshold M.closure A r

theorem BooleanClosureBEC.threshold_zero_eq_closure
    {X : Type u} (M : BooleanClosureBEC X) (A : Set X) :
    M.threshold A BoolV.zero = M.closure.cl A :=
  boolean_threshold_zero_eq_closure M.closure A

end TopologyFragment
end BECv2


/-! M5 component: BECv2_BTTCheck.lean -/
namespace BECv2
namespace Foundation

universe u v w z

class BoundaryTypeTheory where
  Ctx : Type u
  Ty : Type v
  Elem : Ty -> Type w
  Ref : Ty -> Type w
  Boundary : {A : Ty} -> Ref A -> Type w

  Assump : Type z
  hasAssump : Ctx -> Assump -> Prop

  ExcessVal : Type z
  le : ExcessVal -> ExcessVal -> Prop
  zero : ExcessVal
  top : ExcessVal
  excess : {A : Ty} -> Ref A -> Elem A -> ExcessVal

  Form : Type z
  holds : Ctx -> Form -> Prop

  Cert : Ctx -> Form -> Type z
  Obstruction : Ctx -> Form -> Type z

  Route : Form -> Form -> Type z
  requires : {phi psi : Form} -> Route phi psi -> Set Assump

  cert_sound : forall {Gamma : Ctx} {phi : Form}, Cert Gamma phi -> holds Gamma phi

  obstruction_of_missing :
    forall {Gamma : Ctx} {phi psi : Form} (rho : Route phi psi),
      (exists a : Assump, a ∈ requires rho /\ Not (hasAssump Gamma a)) ->
        Obstruction Gamma psi

inductive PrimitiveJudgment
    (BT : BoundaryTypeTheory.{u, v, w, z}) :
    Type (max (max u v) (max w z)) where
  | isType :
      BT.Ctx -> BT.Ty -> PrimitiveJudgment BT
  | isRef :
      (Gamma : BT.Ctx) -> (A : BT.Ty) -> BT.Ref A -> PrimitiveJudgment BT
  | isBoundary :
      (Gamma : BT.Ctx) -> {A : BT.Ty} -> (R : BT.Ref A) ->
        BT.Boundary R -> PrimitiveJudgment BT
  | isElem :
      (Gamma : BT.Ctx) -> (A : BT.Ty) -> BT.Elem A -> PrimitiveJudgment BT
  | hasExcess :
      (Gamma : BT.Ctx) -> {A : BT.Ty} -> (R : BT.Ref A) ->
        BT.Elem A -> BT.ExcessVal -> PrimitiveJudgment BT
  | thresholdMem :
      (Gamma : BT.Ctx) -> {A : BT.Ty} -> (R : BT.Ref A) ->
        BT.Elem A -> BT.ExcessVal -> PrimitiveJudgment BT
  | hasCert :
      (Gamma : BT.Ctx) -> (phi : BT.Form) ->
        BT.Cert Gamma phi -> PrimitiveJudgment BT
  | hasObstruction :
      (Gamma : BT.Ctx) -> (phi : BT.Form) ->
        BT.Obstruction Gamma phi -> PrimitiveJudgment BT

def thresholdPred
    (BT : BoundaryTypeTheory.{u, v, w, z})
    {A : BT.Ty} (R : BT.Ref A) (r : BT.ExcessVal) :
    BT.Elem A -> Prop :=
  fun x => BT.le (BT.excess R x) r

def shellPred
    (BT : BoundaryTypeTheory.{u, v, w, z})
    {A : BT.Ty} (R : BT.Ref A)
    (r s : BT.ExcessVal)
    (lt : BT.ExcessVal -> BT.ExcessVal -> Prop) :
    BT.Elem A -> Prop :=
  fun x => lt r (BT.excess R x) /\ BT.le (BT.excess R x) s

structure ConservativeInterpretation
    (BT : BoundaryTypeTheory.{u, v, w, z}) where
  interpTy : BT.Ty -> Type w
  interpForm : BT.Form -> Prop
  soundCert :
    forall {Gamma : BT.Ctx} {phi : BT.Form},
      BT.Cert Gamma phi -> interpForm phi

structure BTTLogic
    (BT : BoundaryTypeTheory.{u, v, w, z}) where
  B1_zero_le : forall x : BT.ExcessVal, BT.le BT.zero x
  B1_le_top : forall x : BT.ExcessVal, BT.le x BT.top

  B2_threshold_intro :
    forall {A : BT.Ty} (R : BT.Ref A) (r : BT.ExcessVal) (x : BT.Elem A),
      BT.le (BT.excess R x) r -> thresholdPred BT R r x

  B3_shell_intro :
    forall {A : BT.Ty} (R : BT.Ref A) (r s : BT.ExcessVal)
      (lt : BT.ExcessVal -> BT.ExcessVal -> Prop) (x : BT.Elem A),
      lt r (BT.excess R x) ->
      BT.le (BT.excess R x) s ->
      shellPred BT R r s lt x

  B4_profile_extensionality :
    forall {A : BT.Ty} (R S : BT.Ref A),
      (forall x : BT.Elem A, BT.excess R x = BT.excess S x) ->
        Prop

  B5_certificate_sound :
    forall {Gamma : BT.Ctx} {phi : BT.Form},
      BT.Cert Gamma phi -> BT.holds Gamma phi

  B6_obstruction_honesty :
    forall {Gamma : BT.Ctx} {phi psi : BT.Form} (rho : BT.Route phi psi),
      (exists a : BT.Assump,
        a ∈ BT.requires rho /\ Not (BT.hasAssump Gamma a)) ->
        BT.Obstruction Gamma psi

  B7_route_available :
    forall phi psi : BT.Form, BT.Route phi psi -> Prop

  B8_conservative_interpretation :
    Nonempty (ConservativeInterpretation BT)

theorem btt_cert_sound
    (BT : BoundaryTypeTheory.{u, v, w, z})
    {Gamma : BT.Ctx} {phi : BT.Form}
    (C : BT.Cert Gamma phi) :
    BT.holds Gamma phi :=
  BT.cert_sound C

def btt_obstruction_honesty
    (BT : BoundaryTypeTheory.{u, v, w, z})
    {Gamma : BT.Ctx} {phi psi : BT.Form}
    (rho : BT.Route phi psi)
    (h : exists a : BT.Assump,
      a ∈ BT.requires rho /\ Not (BT.hasAssump Gamma a)) :
    BT.Obstruction Gamma psi :=
  BT.obstruction_of_missing rho h

theorem conservative_certificate_sound
    {BT : BoundaryTypeTheory.{u, v, w, z}}
    (I : ConservativeInterpretation BT)
    {Gamma : BT.Ctx} {phi : BT.Form}
    (C : BT.Cert Gamma phi) :
    I.interpForm phi :=
  I.soundCert C

@[reducible] def TrivialBTT : BoundaryTypeTheory where
  Ctx := Unit
  Ty := Unit
  Elem := fun _ => Unit
  Ref := fun _ => Unit
  Boundary := fun _ => Unit
  Assump := Empty
  hasAssump := fun _ a => nomatch a
  ExcessVal := Unit
  le := fun _ _ => True
  zero := ()
  top := ()
  excess := fun _ _ => ()
  Form := Unit
  holds := fun _ _ => True
  Cert := fun _ _ => Unit
  Obstruction := fun _ _ => Unit
  Route := fun _ _ => Unit
  requires := fun _ => ∅
  cert_sound := by
    intro Gamma phi C
    trivial
  obstruction_of_missing := by
    intro Gamma phi psi rho h
    exact ()

def TrivialInterpretation : ConservativeInterpretation TrivialBTT where
  interpTy := fun _ => Unit
  interpForm := fun _ => True
  soundCert := by
    intro Gamma phi C
    trivial

example :
    TrivialBTT.holds () () :=
  btt_cert_sound TrivialBTT (Gamma := ()) (phi := ()) ()

example :
    TrivialInterpretation.interpForm () :=
  conservative_certificate_sound
    (BT := TrivialBTT)
    TrivialInterpretation
    (Gamma := ())
    (phi := ())
    ()

end Foundation
end BECv2

