#!/usr/bin/env bash
set -euo pipefail

echo "[BEC v2.0 M7] All-in-one kernel check"

if [ ! -f lakefile.lean ] && [ ! -f lakefile.toml ]; then
  echo "ERROR: run from a Lean/Lake project root."
  exit 1
fi

if [ ! -f BECv2_AllInOne_Check.lean ]; then
  echo "ERROR: BECv2_AllInOne_Check.lean is missing."
  exit 1
fi

echo
echo "[1/3] Lean version"
lake env lean --version

echo
echo "[2/3] Compile check"
lake env lean BECv2_AllInOne_Check.lean

echo
echo "[3/3] Blocked-token scan"
if grep -nE '(^|[^A-Za-z])(sorry|admit|axiom|unsafe)([^A-Za-z]|$)' BECv2_AllInOne_Check.lean; then
  echo "ERROR: blocked token found."
  exit 1
else
  echo "PASS: blocked-token scan clean."
fi

echo
echo "PASS: BECv2_AllInOne_Check.lean compiled successfully."
