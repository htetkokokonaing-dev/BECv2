# BEC v2.0 M7 All-in-One Kernel Check

This package merges the previously verified milestone source files M1-M5 into one Lean file:

`BECv2_AllInOne_Check.lean`

Run from a Lean/Lake Mathlib project root:

```bash
unzip -o BECv2_M7_AllInOneCheck_FILES.zip
chmod +x check_becv2_m7.sh
./check_becv2_m7.sh
```

Expected result:

```text
PASS: blocked-token scan clean.
PASS: BECv2_AllInOne_Check.lean compiled successfully.
```

This milestone checks that the M1-M5 kernels coexist in a single Lean namespace tree.
