# BEC v2.0 M13 Solver Backend Certificate Importer

Fixed5 version.

The prior version omitted the full implicit binders for importer metadata functions. This version provides explicit `{n m P x r}` binders for every importer function.

Run from a Lean/Lake Mathlib project root:

```bash
unzip -o BECv2_M13_BackendImporterCheck_FILES_FIXED5.zip
chmod +x check_becv2_m13.sh
./check_becv2_m13.sh
```
