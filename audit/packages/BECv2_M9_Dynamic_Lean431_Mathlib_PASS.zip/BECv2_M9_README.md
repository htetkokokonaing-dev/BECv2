# BEC v2.0 M9 Dynamic Generator Kernel Check

Fixed version: `radius_nonzero` uses propositional disequality `≠` rather than boolean `!=`.

Run from a Lean/Lake Mathlib project root:

```bash
unzip -o BECv2_M9_DynamicCheck_FILES_FIXED.zip
chmod +x check_becv2_m9.sh
./check_becv2_m9.sh
```
