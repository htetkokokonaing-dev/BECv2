#!/usr/bin/env bash
set -euo pipefail

echo "[BEC v2.0 M15] Publication package reproducibility helper"
echo

if [ ! -f lakefile.lean ] && [ ! -f lakefile.toml ]; then
  echo "ERROR: run this helper from a Lean/Lake Mathlib project root."
  exit 1
fi

echo "[1/2] Lean version"
lake env lean --version

echo
echo "[2/2] Instructions"
echo "Copy one milestone package at a time into this directory, unzip it, and run its included check script."
echo
echo "Examples:"
echo "  unzip -o BECv2_M14_Categorical_Lean431_Mathlib_PASS.zip"
echo "  chmod +x check_becv2_m14.sh"
echo "  ./check_becv2_m14.sh"
echo
echo "This helper is intentionally non-destructive and does not overwrite source files."
